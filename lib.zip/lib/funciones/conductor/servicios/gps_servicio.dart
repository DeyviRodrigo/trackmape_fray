import 'package:geolocator/geolocator.dart';

class GpsServicio {

  static Future<bool> verificarPermiso() async {

    bool servicioActivo = await Geolocator.isLocationServiceEnabled();

    if (!servicioActivo) {
      return false;
    }

    LocationPermission permiso = await Geolocator.checkPermission();

    if (permiso == LocationPermission.denied) {
      permiso = await Geolocator.requestPermission();
    }

    return permiso == LocationPermission.always ||
        permiso == LocationPermission.whileInUse;
  }

  static Stream<Position> obtenerStream() {

    return Geolocator.getPositionStream(

      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 5,
      ),

    );
  }
}