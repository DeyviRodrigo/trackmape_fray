import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:trackmape_sup/funciones/conductor/datos/repositorio_conductor.dart';
import 'package:trackmape_sup/funciones/conductor/datos/database_local.dart';
import 'package:trackmape_sup/funciones/conductor/servicios/sincronizacion_servicio.dart';

class GpsServicio {

  final RepositorioConductor _repo = RepositorioConductor();
  final DatabaseLocal _dbLocal = DatabaseLocal.instance;
  final SincronizacionServicio _sincronizacion = SincronizacionServicio.instance;

  Timer? _timer;
  bool _enviando = false;

  // ============================================
  // 🌐 ESTADO DE CONECTIVIDAD
  // ============================================
  bool _tieneInternet = false;
  String tipoConexion = "Verificando...";
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;

  // ============================================
  // 📊 ESTADÍSTICAS PARA UI
  // ============================================
  int enviosExitosos = 0;
  int enviosFallidos = 0;
  int guardadosLocal = 0;  // Guardados en SQLite
  int pendientesSincronizar = 0;
  String ultimoError = "";
  String ultimaUbicacion = "";
  DateTime? ultimoEnvioExitoso;

  // Callback para notificar cambios a la UI
  Function(String mensaje, bool esError)? onEstadoCambiado;

  // ============================================
  // ⏱️ INTERVALO DE ENVÍO (segundos)
  // ============================================
  static const int intervaloSegundos = 5;

  /// Inicia el envío periódico de GPS
  Future<void> iniciar(String idDispositivo) async {

    debugPrint("🚀 GPS Servicio: Iniciando para dispositivo $idDispositivo");
    _notificar("Iniciando GPS...", false);

    // Verificar permisos primero
    bool permisosOk = await _verificarPermisos();
    if (!permisosOk) {
      debugPrint("❌ GPS Servicio: Sin permisos de ubicación");
      _notificar("Sin permisos de ubicación", true);
      return;
    }

    // Cancelar timer anterior si existe
    _timer?.cancel();
    _connectivitySubscription?.cancel();

    // Resetear estadísticas
    enviosExitosos = 0;
    enviosFallidos = 0;
    guardadosLocal = 0;
    ultimoError = "";

    // Iniciar escucha de conectividad
    _escucharConectividad();

    // Iniciar servicio de sincronización
    _sincronizacion.iniciar();
    _sincronizacion.onPendientesActualizados = (pendientes) {
      pendientesSincronizar = pendientes;
      _notificar("", false); // Actualizar UI
    };

    // Obtener pendientes actuales
    pendientesSincronizar = await _dbLocal.contarPendientes();

    // Enviar primera posición inmediatamente
    await _enviarPosicionActual(idDispositivo);

    // Iniciar timer para envíos periódicos
    _timer = Timer.periodic(Duration(seconds: intervaloSegundos), (timer) async {
      await _enviarPosicionActual(idDispositivo);
    });

    debugPrint("✅ GPS Servicio: Timer iniciado (cada $intervaloSegundos segundos)");
  }

  void _escucharConectividad() {
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((results) {
      _actualizarEstadoConexion(results);
    });
    Connectivity().checkConnectivity().then(_actualizarEstadoConexion);
  }

  void _actualizarEstadoConexion(List<ConnectivityResult> results) {
    if (results.contains(ConnectivityResult.wifi)) {
      _tieneInternet = true;
      tipoConexion = "WiFi";
    } else if (results.contains(ConnectivityResult.mobile)) {
      _tieneInternet = true;
      tipoConexion = "Datos";
    } else if (results.contains(ConnectivityResult.ethernet)) {
      _tieneInternet = true;
      tipoConexion = "Ethernet";
    } else {
      _tieneInternet = false;
      tipoConexion = "Sin conexión";
    }
    _notificar("", false); // Actualizar UI
  }

  /// Verifica y solicita permisos de ubicación
  Future<bool> _verificarPermisos() async {

    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      debugPrint("⚠️ GPS: Servicio de ubicación deshabilitado");
      ultimoError = "Servicio de ubicación deshabilitado";
      return false;
    }

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        debugPrint("⚠️ GPS: Permiso denegado");
        ultimoError = "Permiso de ubicación denegado";
        return false;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      debugPrint("⚠️ GPS: Permiso denegado permanentemente");
      ultimoError = "Permiso denegado permanentemente";
      return false;
    }

    debugPrint("✅ GPS: Permisos OK");
    return true;
  }

  /// Obtiene y envía la posición actual
  Future<void> _enviarPosicionActual(String idDispositivo) async {

    // Evitar envíos simultáneos
    if (_enviando) {
      debugPrint("⏳ GPS: Ya hay un envío en progreso, saltando...");
      return;
    }

    _enviando = true;

    try {

      debugPrint("📍 GPS: Obteniendo ubicación...");

      Position pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 15),
      );

      ultimaUbicacion = "Lat: ${pos.latitude.toStringAsFixed(6)}, Lon: ${pos.longitude.toStringAsFixed(6)}";
      debugPrint("📍 GPS: $ultimaUbicacion");

      // Validar coordenadas
      if (pos.latitude == 0.0 || pos.longitude == 0.0) {
        debugPrint("⚠️ GPS: Coordenadas inválidas (0,0), saltando...");
        ultimoError = "Coordenadas inválidas (0,0)";
        _notificar("GPS: Coordenadas inválidas", true);
        _enviando = false;
        return;
      }

      // ============================================
      // 🌐 VERIFICAR CONEXIÓN Y DECIDIR DESTINO
      // ============================================
      if (_tieneInternet) {
        // CON INTERNET → Enviar a Supabase
        await _enviarASupabase(idDispositivo, pos);
      } else {
        // SIN INTERNET → Guardar en SQLite
        await _guardarEnLocal(idDispositivo, pos);
      }

    } on TimeoutException {
      enviosFallidos++;
      ultimoError = "Timeout obteniendo ubicación";
      debugPrint("⏱️ GPS: $ultimoError");
      _notificar(ultimoError, true);
    } on LocationServiceDisabledException {
      enviosFallidos++;
      ultimoError = "GPS desactivado";
      debugPrint("❌ GPS: $ultimoError");
      _notificar(ultimoError, true);
    } catch (e) {
      enviosFallidos++;
      ultimoError = e.toString();
      debugPrint("❌ GPS Error: $ultimoError");
      _notificar("Error: $ultimoError", true);
    } finally {
      _enviando = false;
    }
  }

  /// Enviar posición a Supabase
  Future<void> _enviarASupabase(String idDispositivo, Position pos) async {
    debugPrint("📤 GPS: Enviando a Supabase...");

    final resultado = await _repo.enviarPosicionConDetalle(
      idDispositivo: idDispositivo,
      lat: pos.latitude,
      lon: pos.longitude,
      altitud: pos.altitude,
    );

    if (resultado['exito'] == true) {
      enviosExitosos++;
      ultimoEnvioExitoso = DateTime.now();
      ultimoError = "";
      debugPrint("✅ GPS: Envío #$enviosExitosos exitoso (Supabase)");
      _notificar("☁️ Enviado a servidor", false);
    } else {
      // Si falla el envío, guardar localmente
      debugPrint("⚠️ GPS: Fallo Supabase, guardando local...");
      await _guardarEnLocal(idDispositivo, pos);
    }
  }

  /// Guardar posición en SQLite local
  Future<void> _guardarEnLocal(String idDispositivo, Position pos) async {
    debugPrint("💾 GPS: Guardando en SQLite (sin internet)...");

    try {
      await _dbLocal.guardarPosicionLocal(
        fkEmisor: idDispositivo,
        lat: pos.latitude,
        lon: pos.longitude,
        altitud: pos.altitude,
      );

      guardadosLocal++;
      pendientesSincronizar = await _dbLocal.contarPendientes();
      ultimoError = "";
      debugPrint("💾 GPS: Guardado local #$guardadosLocal (pendientes: $pendientesSincronizar)");
      _notificar("💾 Guardado local ($pendientesSincronizar pendientes)", false);

    } catch (e) {
      enviosFallidos++;
      ultimoError = "Error guardando local: $e";
      debugPrint("❌ GPS: $ultimoError");
      _notificar(ultimoError, true);
    }
  }

  void _notificar(String mensaje, bool esError) {
    onEstadoCambiado?.call(mensaje, esError);
  }

  /// Detiene el envío de GPS
  void detener() {
    _timer?.cancel();
    _timer = null;
    _connectivitySubscription?.cancel();
    _enviando = false;
    _sincronizacion.detener();
    debugPrint("🛑 GPS Servicio: Detenido");
    _notificar("GPS detenido", false);
  }

  /// Verifica si el GPS está activo
  bool get estaActivo => _timer != null && _timer!.isActive;
  bool get tieneInternet => _tieneInternet;

  /// Forzar sincronización manual
  Future<void> forzarSincronizacion() async {
    await _sincronizacion.forzarSincronizacion();
    pendientesSincronizar = await _dbLocal.contarPendientes();
    _notificar("", false);
  }

  /// Resumen de estadísticas
  String get resumen => "☁️$enviosExitosos 💾$guardadosLocal ❌$enviosFallidos";
}