import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:trackmape_sup/funciones/conductor/datos/database_local.dart';
import 'package:trackmape_sup/funciones/conductor/datos/repositorio_conductor.dart';

/// ============================================
/// 🔄 SERVICIO DE SINCRONIZACIÓN
/// ============================================
/// Sincroniza automáticamente los datos locales
/// con Supabase cuando hay conexión a internet.
///
class SincronizacionServicio {

  static final SincronizacionServicio instance = SincronizacionServicio._init();

  SincronizacionServicio._init();

  final DatabaseLocal _dbLocal = DatabaseLocal.instance;
  final RepositorioConductor _repo = RepositorioConductor();

  Timer? _timerSincronizacion;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;

  bool _sincronizando = false;
  bool _tieneInternet = false;

  // Callbacks para notificar cambios
  Function(int pendientes)? onPendientesActualizados;
  Function(String mensaje)? onSincronizacionCompleta;

  // ============================================
  // 🚀 INICIAR SERVICIO
  // ============================================
  void iniciar() {
    debugPrint("🔄 Sincronización: Servicio iniciado");

    // Escuchar cambios de conectividad
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((results) {
      _verificarConectividad(results);
    });

    // Verificar estado inicial
    Connectivity().checkConnectivity().then(_verificarConectividad);

    // Timer para sincronización periódica (cada 30 segundos)
    _timerSincronizacion = Timer.periodic(
      const Duration(seconds: 30),
          (_) => sincronizarPendientes(),
    );
  }

  void _verificarConectividad(List<ConnectivityResult> results) {
    final teniaInternet = _tieneInternet;

    _tieneInternet = results.contains(ConnectivityResult.wifi) ||
        results.contains(ConnectivityResult.mobile) ||
        results.contains(ConnectivityResult.ethernet);

    // Si recuperó internet, sincronizar inmediatamente
    if (!teniaInternet && _tieneInternet) {
      debugPrint("🌐 Sincronización: Internet recuperado, sincronizando...");
      sincronizarPendientes();
    }
  }

  // ============================================
  // 🔄 SINCRONIZAR PENDIENTES
  // ============================================
  Future<void> sincronizarPendientes() async {
    if (_sincronizando) {
      debugPrint("⏳ Sincronización: Ya hay una sincronización en progreso");
      return;
    }

    if (!_tieneInternet) {
      debugPrint("📴 Sincronización: Sin internet, saltando...");
      return;
    }

    _sincronizando = true;
    int sincronizados = 0;
    int fallidos = 0;

    try {
      // Obtener pendientes
      final pendientes = await _dbLocal.obtenerPendientes(limite: 20);

      if (pendientes.isEmpty) {
        debugPrint("✅ Sincronización: No hay pendientes");
        _sincronizando = false;
        return;
      }

      debugPrint("📤 Sincronización: ${pendientes.length} registros pendientes");

      for (final registro in pendientes) {
        try {
          final resultado = await _repo.enviarPosicionConDetalle(
            idDispositivo: registro['fk_emisor'],
            lat: registro['lat_grados'],
            lon: registro['lon_grados'],
            altitud: registro['alt_msnm']?.toDouble(),
          );

          if (resultado['exito'] == true) {
            await _dbLocal.marcarSincronizado(registro['id']);
            sincronizados++;
          } else {
            await _dbLocal.incrementarIntentos(registro['id']);
            fallidos++;
            debugPrint("❌ Sincronización: Error - ${resultado['mensaje']}");
          }

          // Pequeña pausa entre envíos para no saturar
          await Future.delayed(const Duration(milliseconds: 100));

        } catch (e) {
          await _dbLocal.incrementarIntentos(registro['id']);
          fallidos++;
          debugPrint("❌ Sincronización: Excepción - $e");
        }
      }

      // Limpiar registros sincronizados
      await _dbLocal.limpiarSincronizados();

      // Limpiar registros que fallaron muchas veces
      await _dbLocal.limpiarFallidos();

      // Notificar
      final pendientesRestantes = await _dbLocal.contarPendientes();
      onPendientesActualizados?.call(pendientesRestantes);

      if (sincronizados > 0) {
        onSincronizacionCompleta?.call("$sincronizados registros sincronizados");
        debugPrint("✅ Sincronización: $sincronizados enviados, $fallidos fallidos");
      }

    } catch (e) {
      debugPrint("❌ Sincronización: Error general - $e");
    } finally {
      _sincronizando = false;
    }
  }

  // ============================================
  // 📊 OBTENER ESTADO
  // ============================================
  Future<int> obtenerPendientes() async {
    return await _dbLocal.contarPendientes();
  }

  bool get tieneInternet => _tieneInternet;
  bool get estaSincronizando => _sincronizando;

  // ============================================
  // 🛑 DETENER SERVICIO
  // ============================================
  void detener() {
    _timerSincronizacion?.cancel();
    _connectivitySubscription?.cancel();
    debugPrint("🛑 Sincronización: Servicio detenido");
  }

  // ============================================
  // 🔄 FORZAR SINCRONIZACIÓN
  // ============================================
  Future<void> forzarSincronizacion() async {
    debugPrint("🔄 Sincronización: Forzando sincronización...");
    await sincronizarPendientes();
  }
}
