import 'package:device_info_plus/device_info_plus.dart';
import 'dart:io';

class IdentificadorDispositivo {

  static Future<String> obtenerId() async {

    final deviceInfo = DeviceInfoPlugin();

    if (Platform.isAndroid) {

      final android = await deviceInfo.androidInfo;
      return android.id; // ANDROID ID único

    } else if (Platform.isIOS) {

      final ios = await deviceInfo.iosInfo;
      return ios.identifierForVendor ?? "ios_unknown";

    }

    return "unknown_device";
  }
}