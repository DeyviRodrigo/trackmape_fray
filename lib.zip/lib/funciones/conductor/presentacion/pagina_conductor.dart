import 'package:flutter/material.dart';
import 'package:trackmape_sup/funciones/conductor/datos/repositorio_conductor.dart';
import 'package:trackmape_sup/funciones/conductor/servicios/gps_servicio.dart';
import 'package:trackmape_sup/funciones/conductor/servicios/identificador_dispositivo.dart';

class PaginaConductor extends StatefulWidget {
  const PaginaConductor({super.key});

  @override
  State<PaginaConductor> createState() => _PaginaConductorState();
}

class _PaginaConductorState extends State<PaginaConductor> {

  final repositorio = RepositorioConductor();

  String? deviceId;

  bool registrado = false;
  bool gpsActivo = false;

  @override
  void initState() {
    super.initState();
    _inicializar();
  }

  Future<void> _inicializar() async {

    deviceId = await IdentificadorDispositivo.obtenerId();

    bool existe = await repositorio.existeEquipo(deviceId!);

    setState(() {
      registrado = existe;
    });
  }

  void _activarGPS() async {

    bool permiso = await GpsServicio.verificarPermiso();

    if (!permiso) return;

    setState(() {
      gpsActivo = true;
    });

    GpsServicio.obtenerStream().listen((pos) {

      repositorio.enviarPosicion(
          id: deviceId!,
          lat: pos.latitude,
          lon: pos.longitude
      );

    });

  }

  void _registrar() async {

    await repositorio.registrarEquipo(deviceId!);

    setState(() {
      registrado = true;
    });

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(
        title: const Text("Conductor"),
        backgroundColor: Colors.orange,
      ),

      body: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(

          children: [

            Text("ID dispositivo:\n$deviceId"),

            const SizedBox(height: 20),

            if (!registrado)
              ElevatedButton(
                onPressed: _registrar,
                child: const Text("Registrar dispositivo"),
              ),

            const SizedBox(height: 20),

            if (registrado)

              ElevatedButton(

                style: ElevatedButton.styleFrom(
                    backgroundColor: gpsActivo ? Colors.red : Colors.green
                ),

                onPressed: gpsActivo ? null : _activarGPS,

                child: Text(
                    gpsActivo
                        ? "GPS ACTIVO"
                        : "Activar GPS"
                ),

              )

          ],

        ),

      ),

    );
  }
}