import 'package:supabase_flutter/supabase_flutter.dart';

class RepositorioConductor {

  final supabase = Supabase.instance.client;

  Future<bool> existeEquipo(String id) async {

    final res = await supabase
        .from('equipos_control')
        .select()
        .eq('id_equipo_control', id)
        .maybeSingle();

    return res != null;
  }

  Future<void> registrarEquipo(String id) async {

    await supabase.from('equipos_control').insert({

      'id_equipo_control': id,
      'tipo_equipo_control': 'CELULAR',
      'codigo_equipo_control': id.substring(0,6),
      'nombre_equipo_control': 'Conductor móvil',
      'habilitado': true

    });
  }

  Future<void> enviarPosicion({
    required String id,
    required double lat,
    required double lon
  }) async {

    await supabase.from('posiciones').insert({

      'fk_emisor': id,
      'lat_grados': lat,
      'lon_grados': lon,
      'tiempo': DateTime.now().toIso8601String()

    });

  }

}